const prismaClient = require('./prisma-client');

function createUser() {}

function readUserByEmail(email) {}

module.exports = { createUser, readUserByEmail };
