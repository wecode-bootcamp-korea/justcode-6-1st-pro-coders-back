function signupController(req, res) {
  res.status(500).json({ message: 'not implemented' }); // 구현이 되면 삭제합니다.
}

function loginController(req, res) {
  res.status(500).json({ message: 'not implemented' }); // 구현이 되면 삭제합니다.
}

module.exports = { signupController, loginController };
